//Kwizera remy
//22005000689
package question.three;

public abstract class Shape2D {

	abstract double calcalateArea();
	abstract double calculatePerimeter();
}
